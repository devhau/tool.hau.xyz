<template>
  <router-view class="page-404" />
</template>

<style lang="scss" scoped>
  .page-404 {
    max-height: 100vh;
  }
</style>